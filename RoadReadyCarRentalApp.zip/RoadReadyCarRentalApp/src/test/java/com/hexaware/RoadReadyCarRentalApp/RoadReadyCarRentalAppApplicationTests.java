package com.hexaware.RoadReadyCarRentalApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RoadReadyCarRentalAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
