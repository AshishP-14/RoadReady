package com.hexaware.RoadReadyCarRentalApp.dto;



import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class UserDTO {
    private Long id;
    
    @NotEmpty(message = "First name is required")
    private String firstName;
    @NotEmpty(message = "Last name is required")
    private String lastName;
    
    //@Email(message = "Invalid email address")
    @NotEmpty(message = "Invalid email address")
    private String email;
    
    @NotEmpty(message = "Username is required")
    @Size(min = 6, max = 20, message = "Username must be between 6 and 20 characters")
    //@Pattern(regexp = "[a-zA-Z0-9_-]+", message = "Username can only contain letters, numbers, underscores, and hyphens")
    private String username;
    
    // Password validation can be added if needed
    // For example:
    // @NotBlank(message = "Password is required")
    // @Size(min = 8, message = "Password must be at least 8 characters long")
//    private String password; // Include password for user registration
    
    @Pattern(regexp = "\\d{10}", message = "Phone number must be 10 digits")
    @NotEmpty(message = "Phone number is required")
    private String phoneNumber;
    
    @NotNull(message = "Role is required")
    private String role;
}
