package com.hexaware.RoadReadyCarRentalApp;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.hexaware.RoadReadyCarRentalApp.entity.Role;
import com.hexaware.RoadReadyCarRentalApp.repository.RoleRepository;

@SpringBootApplication
public class RoadReadyCarRentalAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(RoadReadyCarRentalAppApplication.class, args);
	}
	
	@Bean
	public ModelMapper getModelMapper() {
		return new ModelMapper();
	}
}

//@SpringBootApplication
//public class RoadReadyCarRentalAppApplication  implements CommandLineRunner{
//
//	public static void main(String[] args) {
//		SpringApplication.run(RoadReadyCarRentalAppApplication.class, args);
//	}
//	
//	@Bean
//	ModelMapper getModelMapper() {
//		return new ModelMapper();
//	}
//
//	@Autowired
//	private RoleRepository rolerepo;
//	@Override
//	public void run(String... args) throws Exception {
//		// TODO Auto-generated method stub
//		Role roleObj=new Role(1L,"ROLE_USER");
//		Role roleObj2=new Role(2L,"ROLE_ADMIN");
//
//		rolerepo.save(roleObj);
//		rolerepo.save(roleObj2);
//			
//	}
//}