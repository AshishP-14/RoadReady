package com.hexaware.RoadReadyCarRentalApp.service.serviceImpl;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.hexaware.RoadReadyCarRentalApp.customException.BadRequestException;
import com.hexaware.RoadReadyCarRentalApp.dto.LoginDto;
import com.hexaware.RoadReadyCarRentalApp.dto.RegisterDto;
import com.hexaware.RoadReadyCarRentalApp.dto.UserDTO;
import com.hexaware.RoadReadyCarRentalApp.entity.AuthenticationResponse;
import com.hexaware.RoadReadyCarRentalApp.entity.Role;
import com.hexaware.RoadReadyCarRentalApp.entity.User;
import com.hexaware.RoadReadyCarRentalApp.repository.RoleRepository;
import com.hexaware.RoadReadyCarRentalApp.repository.UserRepository;
import com.hexaware.RoadReadyCarRentalApp.security.JwtTokenProvider;
import com.hexaware.RoadReadyCarRentalApp.service.AuthenticationService;





@Service
public class AuthenticationServiceImpl implements AuthenticationService {

	@Autowired
	private UserRepository repository;
	@Autowired
	private PasswordEncoder passwordEncoder;
	@Autowired
	private JwtTokenProvider jwtTokenProvider;
	@Autowired
	private AuthenticationManager authenticationManager;
	@Autowired
	private RoleRepository roleRepo;

	@Override
	public String register(RegisterDto request) {

        // check if user already exist. if exist than authenticate the user
        if(repository.existsByUsername(request.getUsername())) {
            throw new BadRequestException(HttpStatus.BAD_REQUEST, "Username already exist");
        }
        if(repository.existsByEmail(request.getEmail()))
			throw new BadRequestException(HttpStatus.BAD_REQUEST, "Email already exist");
        User user = new User();
        user.setFirstName(request.getFirstName());
        user.setLastName(request.getLastName());
        user.setEmail(request.getEmail());
        user.setPhoneNumber(request.getPhoneNumber());
        user.setUsername(request.getUsername());
        user.setPassword(passwordEncoder.encode(request.getPassword()));

        Set<Role> roles = new HashSet<>();
		Role role = roleRepo.findByName("ROLE_USER").get();
		roles.add(role);
		user.setRoles(roles);

        repository.save(user);

        return "Register Successfull!..";

    }
	
	@Override
	public AuthenticationResponse authenticate(LoginDto request) {
		System.out.println(("object received"+request));
		Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        request.getUsername(),
                        request.getPassword()
                )
        );

		SecurityContextHolder.getContext().setAuthentication(authentication);
		String token = jwtTokenProvider.generateToken(authentication);
		System.out.println("Token generated : "+token);
		
        User user = repository.findByUsername(request.getUsername()).get();
        
        UserDTO userDto = new UserDTO();
        userDto.setId(user.getId());
        userDto.setFirstName(user.getFirstName());
        userDto.setLastName(user.getLastName());
        userDto.setEmail(user.getEmail());
        userDto.setPhoneNumber(user.getPhoneNumber());
        userDto.setUsername(user.getUsername());
//        UserDTO.setPassword(passwordEncoder.encode(user.getPassword()));

        String role = "ROLE_USER";
		Set<Role> roleUser = user.getRoles();
		for(Role roleTemp:roleUser)
		{
			if(roleTemp.getName().equalsIgnoreCase("ROLE_ADMIN"))
				role = "ROLE_ADMIN";
		}
		userDto.setRole(role);
		
        return new AuthenticationResponse(token,"Bearer",userDto);

    }
	

}
