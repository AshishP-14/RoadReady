import axios from 'axios';

const REVIEW_API_BASE_URL = 'http://localhost:8080/api/reviews/';

const ReviewService = {
    getAllReviews(token){
        return axios.get(REVIEW_API_BASE_URL + "getAll", {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
    },

    getReviewById(id, token) {
        return axios.get(REVIEW_API_BASE_URL + "getById/" + id, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
    },

    createNewReview(reviewData,token){
        const response = axios({
            method: 'post',
            url: REVIEW_API_BASE_URL + "add",
            data : reviewData ,
            headers: {  
                'Authorization': `Bearer ${token}`,  
                'Content-Type' : 'application/json'  
             }  
          })
          return  response; 
    },

    updateReview(id, reviewData,token){
        const response= axios({
            method:'put',
            url: REVIEW_API_BASE_URL+"update/"+id ,
            data : reviewData, 
             headers:{ 
                Authorization:`Bearer ${token}`,
                'Content-Type': 'application/json'
              }    
          })
          return response;  
    },

    deleteReview(id, token) {
        const response = axios({
            method: 'delete',
            url: REVIEW_API_BASE_URL + 'delete/' + id,
            data: {},
            headers: {
                Authorization: `Bearer ${token}`,
            }
        })
        return response;
    },


    getReviewsByCarId(carId, token) {
        return axios.get(REVIEW_API_BASE_URL + "car/" + carId, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
    },

    getReviewsByUserID(userID, token) {
        return axios.get(REVIEW_API_BASE_URL + "user/" + userID, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
    },

    getAvgReviews(id, token) {
        return axios.get(REVIEW_API_BASE_URL + "car/averagerRating", {
            params: {
                carId: id
            },
            headers: {
                "Authorization": `Bearer ${token}`
            }
        });
    },
};

export default ReviewService;