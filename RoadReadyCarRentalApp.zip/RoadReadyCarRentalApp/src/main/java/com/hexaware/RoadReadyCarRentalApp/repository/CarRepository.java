package com.hexaware.RoadReadyCarRentalApp.repository;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hexaware.RoadReadyCarRentalApp.entity.Car;
import com.hexaware.RoadReadyCarRentalApp.entity.Car.CarType;
import com.hexaware.RoadReadyCarRentalApp.entity.Car.FuelType;
import com.hexaware.RoadReadyCarRentalApp.entity.Car.TransmissionType;

@Repository
public interface CarRepository extends JpaRepository<Car,Long> {
	
	List<Car> findByLocationAndAvailability(String location, boolean availability);

	List<Car> findByCarTypeAndAvailability(CarType carType, boolean availability);

	List<Car> findByLocationAndCarTypeAndAvailability(String location, CarType carType, boolean availability);

	List<Car> findByBrand(String brand);
	List<Car> findByModel(String model);
    List<Car> findByColor(String color);
    List<Car> findByAvailability(boolean availability);
    List<Car> findByPriceBetween(double minPrice, double maxPrice);
    List<Car> findByBrandAndColorAndAvailability(String brand, String color, boolean availability);
    List<Car> findByPriceLessThan(double price);
    List<Car> findByPriceGreaterThan(double price);
    List<Car> findByTransmissionTypeAndAvailability(TransmissionType transmissionType, boolean availability);
    List<Car> findByFuelTypeAndAvailability(FuelType fuelType, boolean availability);
    
    List<Car> findByBrandAndPriceBetween(String brand, double minPrice, double maxPrice);
    List<Car> findByLocationAndTransmissionTypeAndAvailability(String location,TransmissionType transmissionType, boolean availability);

//    List<Car> findAllSorted(String sortBy);
//    List<Car> findByAvailabilityAndSort(boolean available, String sortBy);
    List<Car> findByAvailability(boolean available, Sort sort);

	List<Car> findByAvailabilityAndCarTypeIn(boolean availability, List<String> carTypes, Sort sort);

	List<Car> findByCarTypeIn(List<String> carTypes, Sort sort);
	
	

	List<Car> findByAvailabilityAndCarTypeInAndFuelTypeInAndTransmissionTypeIn(boolean availability,
			List<String> carTypes, List<String> fuelTypes, List<String> transmissionTypes, Sort sort);

	List<Car> findByAvailabilityAndCarTypeInAndFuelTypeIn(boolean availability, List<String> carTypes,
			List<String> fuelTypes, Sort sort);

	List<Car> findByAvailabilityAndCarTypeInAndTransmissionTypeIn(boolean availability, List<String> carTypes,
			List<String> transmissionTypes, Sort sort);

	List<Car> findByAvailabilityAndFuelTypeInAndTransmissionTypeIn(boolean availability, List<String> fuelTypes,
			List<String> transmissionTypes, Sort sort);

	List<Car> findByAvailabilityAndFuelTypeIn(boolean availability, List<String> fuelTypes, Sort sort);

	List<Car> findByAvailabilityAndTransmissionTypeIn(boolean availability, List<String> transmissionTypes, Sort sort);

	List<Car> findByCarTypeInAndFuelTypeInAndTransmissionTypeIn(List<String> carTypes, List<String> fuelTypes,
			List<String> transmissionTypes, Sort sort);

	List<Car> findByCarTypeInAndFuelTypeIn(List<String> carTypes, List<String> fuelTypes, Sort sort);

	List<Car> findByCarTypeInAndTransmissionTypeIn(List<String> carTypes, List<String> transmissionTypes, Sort sort);

	List<Car> findByFuelTypeInAndTransmissionTypeIn(List<String> fuelTypes, List<String> transmissionTypes, Sort sort);

	List<Car> findByFuelTypeIn(List<String> fuelTypes, Sort sort);

	List<Car> findByTransmissionTypeIn(List<String> transmissionTypes, Sort sort);
	
	

	List<Car> findByAvailabilityAndLocation(boolean availability, String location, Sort sort);

	List<Car> findByLocation(String location, Sort sort);

	List<Car> findByAvailabilityAndLocationAndCarTypeInAndFuelTypeInAndTransmissionTypeIn(boolean availability,
			String location, List<String> carTypes, List<String> fuelTypes, List<String> transmissionTypes, Sort sort);

	List<Car> findByAvailabilityAndLocationAndCarTypeInAndFuelTypeIn(boolean availability, String location,
			List<String> carTypes, List<String> fuelTypes, Sort sort);

	
	List<Car> findByAvailabilityAndLocationAndCarTypeInAndTransmissionTypeIn(boolean availability, String location,
			List<String> carTypes, List<String> transmissionTypes, Sort sort);

	List<Car> findByAvailabilityAndLocationAndFuelTypeInAndTransmissionTypeIn(boolean availability, String location,
			List<String> fuelTypes, List<String> transmissionTypes, Sort sort);

	List<Car> findByAvailabilityAndLocationAndCarTypeIn(boolean availability, String location, List<String> carTypes,
			Sort sort);

	List<Car> findByAvailabilityAndLocationAndFuelTypeIn(boolean availability, String location, List<String> fuelTypes,
			Sort sort);

	List<Car> findByAvailabilityAndLocationAndTransmissionTypeIn(boolean availability, String location,
			List<String> transmissionTypes, Sort sort);

	List<Car> findByLocationAndCarTypeInAndFuelTypeInAndTransmissionTypeIn(String location, List<String> carTypes,
			List<String> fuelTypes, List<String> transmissionTypes, Sort sort);

	List<Car> findByLocationAndCarTypeInAndFuelTypeIn(String location, List<String> carTypes, List<String> fuelTypes,
			Sort sort);

	List<Car> findByLocationAndCarTypeInAndTransmissionTypeIn(String location, List<String> carTypes,
			List<String> transmissionTypes, Sort sort);

	List<Car> findByLocationAndFuelTypeInAndTransmissionTypeIn(String location, List<String> fuelTypes,
			List<String> transmissionTypes, Sort sort);

	List<Car> findByLocationAndCarTypeIn(String location, List<String> carTypes, Sort sort);

	List<Car> findByLocationAndFuelTypeIn(String location, List<String> fuelTypes, Sort sort);

	List<Car> findByLocationAndTransmissionTypeIn(String location, List<String> transmissionTypes, Sort sort);
}
