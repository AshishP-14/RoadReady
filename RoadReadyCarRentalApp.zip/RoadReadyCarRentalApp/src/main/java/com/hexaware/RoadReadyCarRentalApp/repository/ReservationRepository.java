package com.hexaware.RoadReadyCarRentalApp.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hexaware.RoadReadyCarRentalApp.entity.Reservation;

@Repository
public interface ReservationRepository extends JpaRepository<Reservation,Long>{
	
	List<Reservation> findByUserId(Long userID);

    List<Reservation> findByCarId(Long carId);
	
    @Query("SELECT r FROM Reservation r " +
            "WHERE r.car.id = :carId " +
            "AND ((r.pickupDateTime BETWEEN :startDateTime AND :endDateTime) " +
            "OR (r.dropOffDateTime BETWEEN :startDateTime AND :endDateTime))")
    List<Reservation> findOverlappingReservations(@Param("carId") Long carId,@Param("startDateTime") LocalDateTime pickupDateTime,@Param("endDateTime") LocalDateTime dropOffDateTime);
}
