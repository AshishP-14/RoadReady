import React, { useContext, useState } from 'react'
import { Menu, X, ChevronRight, CircleUser, LogOut } from 'lucide-react'
import { Link, useNavigate } from 'react-router-dom'
import logoImg from '../images/Logo.png';
import { AuthContext } from '../context/AuthProvider';

const menuItems = [
  {
    name: 'Home',
    to: '/',
  },
  {
    name: 'Cars',
    to: '/cars/getAll',
  },

]

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false)
  const [isOpen, setIsOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen)
  }
  const navigate = useNavigate();

  const handleclick = () => {
    navigate('/register')

  }

  const handlelogin = () => {
    navigate('/login')
  }

  const { auth, setAuth } = useContext(AuthContext);
  const userID = auth.id;
  const user = auth.role === 'ROLE_USER';

  const logout = async () => {
    const confirmLogout = window.confirm('Are you sure you want to logout?');
    if (confirmLogout) {
      setAuth({});
      navigate('/');
    }
  }

  const handleLogout = () => {
    toggleMenu(); // Close menu
    logout(); // Logout
  };

  const toggleProfileCard = () => {
    setIsOpen(!isOpen);
  };

  return (
    <>
      <div className="fixed top-10 right-10 z-50">

        {isOpen && (

          <div className="fixed top-10 right-10 bg-gray-100 border border-gray-300 shadow-lg rounded-lg p-4 z-50 ">
            <button className="absolute top-2 right-2 text-gray-500" onClick={toggleProfileCard}>
              &times;
            </button>
            <h2 className="text-xl font-semibold mb-4">Welcome {auth.username}</h2>
            <div className="flex flex-col gap-2">
              <Link to="/cars/getAll" className="btn btn-primary">
                All Cars
              </Link>
              <Link to={`/user/reviews/${auth.id}`} className="btn btn-primary">
                Your Reviews
              </Link>
              <Link to={`/user/reservations/${auth.id}`} className="btn btn-primary">
                Your Reservation
              </Link>
              <Link to={`/user/${userID}`} className="btn btn-primary">
                Your Data
              </Link>
            </div>
          </div>
        )}

      </div >

      <div className="relative w-full bg-slate-800">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-2 sm:px-6 lg:px-8">
          <div className="inline-flex items-center space-x-2 bg-slate-200 bg-current rounded-full">
            <Link to='/' >
              <span>
                <img src={logoImg} alt="Logo" className='h-12 w-auto' />
              </span>
            </Link>
          </div>
          <div className="hidden grow items-start lg:flex">
            <ul className="ml-12 inline-flex space-x-8">
              {menuItems.map((item) => (
                <li key={item.name}>
                  <Link
                    to={item.to}
                    className="mt-2 inline-flex items-center text-sm font-semibold border-2  rounded-full text-white btn hover:text-gray-900"
                  >
                    {item.name}
                    {/* <span>
                    <ChevronDown className="ml-2 h-4 w-4" />
                  </span> */}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          <div className="hidden space-x-2 lg:block">
            {userID ? (
              user ? (
                <>
                  <button
                    type="button"
                    className="rounded-md border  border-white px-3 py-2   text-sm font-semibold text-white shadow-sm focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-black"
                    onClick={toggleProfileCard}
                  >
                    <CircleUser />
                    {/* Profile */}
                  </button>
                  <button
                    type="button"
                    className="rounded-md border bg-red-500 border-white  px-3 py-2 text-sm font-semibold text-white shadow-sm focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-black"
                    onClick={logout}
                  >
                    <span>
                      <LogOut>
                        Log out
                      </LogOut>
                    </span>
                    {/* Log Out */}
                  </button>
                </>
              ) : (
                <button
                  type="button"
                  className="rounded-md border  bg-red-500 border-white px-3 py-2 text-sm font-semibold text-white shadow-sm focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-black"
                  onClick={logout}
                >
                  Log Out
                </button>
              )
            ) : (
              <>
                <button
                  type="button"
                  className="rounded-md bg-transparent px-3 py-2 text-sm font-semibold text-white hover:bg-black/10 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-black"
                  onClick={handleclick}
                >
                  Sign Up
                </button>
                <button
                  type="button"
                  className="rounded-xl border border-white px-3 py-2 text-sm font-semibold text-white shadow-sm focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-black"
                  onClick={handlelogin}
                >
                  Log In
                </button>
              </>
            )}
          </div>
          <div className="lg:hidden">
            <Menu onClick={toggleMenu} className="h-6 w-6 cursor-pointer" />
          </div>
          {isMenuOpen && (
            <div className="absolute inset-x-0 top-0 z-50 origin-top-right transform p-2 transition lg:hidden">
              <div className="divide-y-2 divide-gray-50 rounded-lg bg-white shadow-lg ring-1 ring-black ring-opacity-5">
                <div className="px-5 pb-6 pt-5">
                  <div className="flex items-center justify-between">
                    <div className="inline-flex items-center space-x-2">
                      <span className="font-bold">Road-Ready</span>
                    </div>
                    <div className="-mr-2">
                      <button
                        type="button"
                        onClick={toggleMenu}
                        className="inline-flex items-center justify-center rounded-md p-2 text-gray-400 hover:bg-gray-100 hover:text-gray-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-black"
                      >
                        <span className="sr-only">Close menu</span>
                        <X className="h-6 w-6" aria-hidden="true" />
                      </button>
                    </div>
                  </div>
                  <div className="mt-6">
                    <nav className="grid gap-y-4">
                      {menuItems.map((item) => (
                        <Link
                          key={item.name}
                          to={item.to}
                          className="-m-3 flex items-center rounded-md p-3 text-sm font-semibold hover:bg-gray-50"
                        >
                          <span className="ml-3 text-base font-medium text-gray-900">
                            {item.name}
                          </span>
                          <span>
                            <ChevronRight className="ml-3 h-4 w-4" />
                          </span>
                        </Link>
                      ))}
                    </nav>
                  </div>
                  <div className="mt-2 space-y-2">
                    {userID ? (
                      <button
                        type="button"
                        className="w-full rounded-md bg-black px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-black/10 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-black"
                        onClick={handleLogout}
                      >
                        Log Out
                      </button>
                    ) : (
                      <>
                        <button
                          type="button"
                          className="w-full rounded-md border border-black px-3 py-2 text-sm font-semibold text-black shadow-sm focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-black"
                          onClick={handleclick}
                        >
                          Sign In
                        </button>
                        <button
                          type="button"
                          className="w-full rounded-md bg-black px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-black/10 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-black"
                          onClick={handlelogin}
                        >
                          Log In
                        </button>
                      </>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  )

}
export default Header;
