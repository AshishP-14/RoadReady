package com.hexaware.RoadReadyCarRentalApp.service.serviceImpl;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hexaware.RoadReadyCarRentalApp.customException.NoDataFoundException;
import com.hexaware.RoadReadyCarRentalApp.customException.ResourceNotFoundException;
import com.hexaware.RoadReadyCarRentalApp.dto.ReservationDTO;
import com.hexaware.RoadReadyCarRentalApp.entity.Car;
import com.hexaware.RoadReadyCarRentalApp.entity.Reservation;
import com.hexaware.RoadReadyCarRentalApp.entity.Reservation.ReservationStatus;
import com.hexaware.RoadReadyCarRentalApp.entity.User;
import com.hexaware.RoadReadyCarRentalApp.repository.CarRepository;
import com.hexaware.RoadReadyCarRentalApp.repository.ReservationRepository;
import com.hexaware.RoadReadyCarRentalApp.repository.UserRepository;
import com.hexaware.RoadReadyCarRentalApp.service.ReservationService;

@Service
public class ReservationServiceImpl implements ReservationService {

	private static final Logger logger = LoggerFactory.getLogger(ReservationServiceImpl.class);

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private ReservationRepository reservationRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private CarRepository carRepository; // Inject CarRepository

	@Override
	public ReservationDTO makeReservation(ReservationDTO reservationDto)
			throws ResourceNotFoundException, NoDataFoundException {
		logger.info("Making reservation: {}", reservationDto);
		try {
			// Map ReservationDTO to Reservation entity
			Reservation reservation = modelMapper.map(reservationDto, Reservation.class);

			// Retrieve the associated Car entity from the database
			Car car = carRepository.findById(reservationDto.getCarId())
					.orElseThrow(() -> new ResourceNotFoundException("Car", "id", reservationDto.getCarId()));

			// Retrieve the associated User entity from the database
			User user = userRepository.findById(reservationDto.getUserId())
					.orElseThrow(() -> new ResourceNotFoundException("User", "id", reservationDto.getUserId()));

			// Check if the car is available before making the reservation
			boolean isCarAvailable = isCarAvailable(car.getId(), reservation.getPickupDateTime(),
					reservation.getDropOffDateTime());

			if (!isCarAvailable) {
				throw new NoDataFoundException("The car is not available for the selected dates.");
			}

			// Associate the retrieved Car entity with the Reservation
			reservation.setCar(car);
			reservation.setUser(user);
			
			// Change reservation status to "Pending"
			reservation.setStatus(Reservation.ReservationStatus.Pending);

			// Save the reservation with updated status
			Reservation savedReservation = reservationRepository.save(reservation);

			// Map saved Reservation entity back to ReservationDTO
			return modelMapper.map(savedReservation, ReservationDTO.class);
		} catch (ResourceNotFoundException e) {
			logger.error("Error making reservation: {}", e.getMessage());
			throw e;
		} catch (NoDataFoundException e) {
			logger.error("Error making reservation: {}", e.getMessage());
			throw e;
		} catch (Exception e) {
			logger.error("Error making reservation", e);
			throw new RuntimeException("An unexpected error occurred while making reservation", e);
		}
	}

	@Override
	public ReservationDTO getReservationById(Long id) throws ResourceNotFoundException {
		logger.info("Fetching reservation by ID: {}", id);
		Reservation reservationById = reservationRepository.findById(id).orElseThrow(() -> {
			logger.error("Error fetching reservation by ID {}: ", id);
			return new ResourceNotFoundException("Reservation", "id", id);
		});
		logger.debug("Fetched Reservation: {}", reservationById);
		ReservationDTO reservationDtoById = modelMapper.map(reservationById, ReservationDTO.class);
		return reservationDtoById;
	}

	@Override
	public List<ReservationDTO> getAllReservations() throws NoDataFoundException {
		logger.info("Fetching all reservations");
		List<Reservation> reservationList = reservationRepository.findAll();
		if (reservationList.isEmpty()) {
			logger.error("Error fetching all reservations ");
			throw new NoDataFoundException("No Reservation found.");
		}
		logger.info("Fetched Reservation: {}", reservationList.size());
		List<ReservationDTO> reservationDTOList = new ArrayList<>();
		for (Reservation reservation : reservationList) {
//			reservationDTOList.add(modelMapper.map(reservation, ReservationDTO.class));
			// Map the Reservation entity to ReservationDTO
	        ReservationDTO reservationDTO = modelMapper.map(reservation, ReservationDTO.class);
	        
	        // Manually set the username and model fields
	        reservationDTO.setUsername(reservation.getUser().getUsername());
	        reservationDTO.setModel(reservation.getCar().getModel());
	        
	        // Add the populated ReservationDTO to the list
	        reservationDTOList.add(reservationDTO);
		}
		return reservationDTOList;
	}

	@Override
	public List<ReservationDTO> getReservationsByUserId(Long userId) throws ResourceNotFoundException {
		logger.info("Fetching reservations by User ID: {}", userId);
		List<Reservation> reservationList = reservationRepository.findByUserId(userId);

		if (reservationList.isEmpty()) {
			logger.error("Error fetching reservations by User ID {}: ", userId);
			throw new ResourceNotFoundException("Reservation", "userId", userId);
		}
		logger.debug("Fetched Reservation: {}", reservationList.size());
		List<ReservationDTO> reservationDTOList = new ArrayList<>();
		for (Reservation reservation : reservationList) {
//			reservationDTOList.add(modelMapper.map(reservation, ReservationDTO.class));
			
			// Map the Reservation entity to ReservationDTO
	        ReservationDTO reservationDTO = modelMapper.map(reservation, ReservationDTO.class);
	        
	        // Manually set the username and model fields
	        reservationDTO.setUsername(reservation.getUser().getUsername());
	        reservationDTO.setModel(reservation.getCar().getModel());
	        
	        // Add the populated ReservationDTO to the list
	        reservationDTOList.add(reservationDTO);
		}
		return reservationDTOList;
	}

	@Override
	public List<ReservationDTO> getReservationsByCarId(Long carId) throws ResourceNotFoundException {
		logger.info("Fetching reservations by Car ID: {}", carId);
		List<Reservation> reservationList = reservationRepository.findByCarId(carId);

		if (reservationList.isEmpty()) {
			logger.error("Error fetching reservations by Car ID {}: ", carId);
			throw new ResourceNotFoundException("Reservation", "carId", carId);
		}
		logger.debug("Fetched Reservation: {}", reservationList.size());
		List<ReservationDTO> reservationDTOList = new ArrayList<>();
		for (Reservation reservation : reservationList) {
			reservationDTOList.add(modelMapper.map(reservation, ReservationDTO.class));
		}
		return reservationDTOList;
	}

	@Override
	public void cancelReservation(Long reservationId) throws ResourceNotFoundException {
		logger.info("Cancelling reservation with ID: {}", reservationId);
		reservationRepository.findById(reservationId).orElseThrow(() -> {
			logger.error("Error cancelling reservation with ID {}: ", reservationId);
			return new ResourceNotFoundException("Reservation", "id", reservationId);
		});
		logger.debug("Reservation deleted successfully with ID: {}", reservationId);
		reservationRepository.deleteById(reservationId);
	}

	@Override
	public boolean isCarAvailable(Long carId, LocalDateTime pickupDateTime, LocalDateTime dropOffDateTime) {
		logger.info("Checking car availability for Car ID: {}, Pickup DateTime: {}, Drop-off DateTime: {}", carId,
				pickupDateTime, dropOffDateTime);
		List<Reservation> overlappingReservations = reservationRepository.findOverlappingReservations(carId,
				pickupDateTime, dropOffDateTime);
		return overlappingReservations.isEmpty();
	}

	// admin will perform this function
	@Override
	public boolean updateReservationStatus(Long id, ReservationStatus newStatus) throws ResourceNotFoundException {
		logger.info("Updating reservation status for Reservation ID: {} to: {}", id, newStatus);
		Reservation reservation = reservationRepository.findById(id).orElseThrow(() -> {
			logger.error("Error updating reservation status for Reservation ID {}: because reservation not found ", id);
			return new ResourceNotFoundException("Reservation", "id", id);
		});

		// Check if the status is changing from Pending to Confirmed
		if (reservation.getStatus() == ReservationStatus.Pending && newStatus == ReservationStatus.Confirmed) {
			Long carId = reservation.getCar().getId();
			Car car = carRepository.findById(carId).orElseThrow(() -> {
				logger.error(
						"Error updating reservation status for Reservation ID {}: because Car not found with id: {}",
						id, carId);
				return new ResourceNotFoundException("Car", "id", carId);
			});
			car.setAvailability(false);
			carRepository.save(car); // Save changes to car availability
		}

		reservation.setStatus(newStatus);
		reservationRepository.save(reservation);
		logger.debug("Reservation updated successfully: {}", reservation);
		return true;
	}
}
