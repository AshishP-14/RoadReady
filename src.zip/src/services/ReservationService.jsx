import axios from 'axios';

const RESERVATION_API_BASE_URL = 'http://localhost:8080/api/reservations/';

const ReservationService = {
    getAllReservations(token) {
        return axios.get(RESERVATION_API_BASE_URL + "all",{
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
    },

    getReservationById(reservationId, token) {
        return axios.get(`${RESERVATION_API_BASE_URL}getById/${reservationId}`, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
    },

    getReservationByUserId(userId, token) {
        return axios.get(`${RESERVATION_API_BASE_URL}user/${userId}`, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
    },

    addReservation(reservation, token) {
        const reponse = axios({
            method: 'post',
            url: `${RESERVATION_API_BASE_URL}make`,
            data: reservation,
            headers: {  
                'Authorization': `Bearer ${token}`,  
                'Content-Type': 'application/json'  
            } 
        })  
        return  reponse;
    },

    updateReservation(reservationId, reservationStatus, token) {
        return axios.put(`${RESERVATION_API_BASE_URL}updateStatus/${reservationId}`, null, {
            params: {
                newStatus: reservationStatus,
            },
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
    },

    deleteReservation(reservationId,token)  {
        return axios.delete(`${RESERVATION_API_BASE_URL}delete/${reservationId}`,{
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
    }
};

export default ReservationService;