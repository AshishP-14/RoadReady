package com.hexaware.RoadReadyCarRentalApp.repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.hexaware.RoadReadyCarRentalApp.entity.Reservation;

@SpringBootTest
public class CustomQueryMethodsTest {

		@Autowired
		private ReservationRepository reservationRepository;
		


		
		
		@Test
	    void testFindOverlappingReservations() {
	        // Prepare test data
	        Long carId = 1L;
	        LocalDateTime startDateTime = LocalDateTime.of(2024, 2, 19, 10, 0);
	        LocalDateTime endDateTime = LocalDateTime.of(2024, 2, 20, 10, 0);

	        // Call the method
	        List<Reservation> result = reservationRepository.findOverlappingReservations(carId, startDateTime, endDateTime);
	        
	        result.forEach((p)->{
				System.out.println(p);
			});

	    }
		
//		@Test
//	    void testFindByToken() {
//	        // Prepare test data
//	        String tokenValue = "sampleToken";
//
//	        // Call the method
//	        Optional<Token> result = tokenRepository.findByToken(tokenValue);
//	        Token token = result.get();
//	        System.out.println(token);
//	        in detailed handle
	        
//	        Optional<Token> result = tokenRepository.findByToken(tokenValue);
//	        result.ifPresent(token -> {
//	            // Handle the case where the token is found
//	            System.out.println("Token found: " + token);
//	        });
	//
//	        // Or handle the case where the token is not found
//	        Token token = result.orElse(null);
//	        if (token == null) {
//	            System.out.println("Token not found");
//	        } else {
//	            System.out.println("Token found: " + token);
//	        }

	        // Assertions
//	        assertEquals(true, result.isPresent()); // Adjust based on your expected result
	    
}
