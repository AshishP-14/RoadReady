package com.hexaware.RoadReadyCarRentalApp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hexaware.RoadReadyCarRentalApp.customException.NoDataFoundException;
import com.hexaware.RoadReadyCarRentalApp.customException.ResourceNotFoundException;
import com.hexaware.RoadReadyCarRentalApp.dto.CarDTO;
import com.hexaware.RoadReadyCarRentalApp.entity.Car;
import com.hexaware.RoadReadyCarRentalApp.entity.Car.FuelType;
import com.hexaware.RoadReadyCarRentalApp.entity.Car.TransmissionType;
import com.hexaware.RoadReadyCarRentalApp.service.CarService;

@RestController
@RequestMapping("/api/cars")
@CrossOrigin(origins = "http://localhost:3000")
public class CarController {

	@Autowired
	private CarService carService;

//	// url = http//localhost:8080/api/cars/getAll
//	@GetMapping("/getAll")
//	public ResponseEntity<List<CarDTO>> getAllCars() throws NoDataFoundException {
//		List<CarDTO> cars = carService.getAllCars();
//		return ResponseEntity.ok(cars);
//	}
	

	// location added 
	@PreAuthorize("hasRole('ROLE_ADMIN') or hasRole('ROLE_USER')")
	@GetMapping("/getAll")
	public ResponseEntity<List<CarDTO>> getAllCars(
	    @RequestParam(required = false) String sortBy,
	    @RequestParam(required = false) Boolean filterByAvailable,
	    @RequestParam(required = false) List<String> filterByCarType,
	    @RequestParam(required = false) List<String> filterByFuelType,
	    @RequestParam(required = false) List<String> filterByTransmissionType,
	    @RequestParam(required = false) String location // Add location parameter
	) throws NoDataFoundException, ResourceNotFoundException {
	    List<CarDTO> cars;
	    if (sortBy != null && filterByAvailable != null && filterByCarType != null &&
	        filterByFuelType != null && filterByTransmissionType != null) {
	        boolean availability = filterByAvailable;
	        cars = carService.getFilteredAndSortedCars(sortBy, availability, filterByCarType,
	                                                   filterByFuelType, filterByTransmissionType,
	                                                   location); // Pass location to service method
	    } else if (sortBy != null && filterByAvailable != null) {
	        boolean availability = filterByAvailable;
	        cars = carService.getFilteredAndSortedCars(sortBy, availability, filterByCarType,
	                                                   filterByFuelType, filterByTransmissionType,
	                                                   location); // Pass location to service method
	    } else if (sortBy != null) {
	        cars = carService.getAllSortedCars(sortBy);
	    } else if (filterByAvailable != null) {
	        boolean availability = filterByAvailable;
	        cars = carService.searchCarsByAvailability(availability);
	    } else {
	        cars = carService.getAllCars();
	    }
	    return ResponseEntity.ok(cars);
	}


	// url = http//localhost:8080/api/cars/getById/3
	@GetMapping("/getById/{id}")
	public ResponseEntity<CarDTO> getCarById(@PathVariable Long id) throws ResourceNotFoundException {
		CarDTO carDTO = carService.getCarById(id);
		return ResponseEntity.ok(carDTO);
	}

	// url = http//localhost:8080/api/cars/addCar
	@PreAuthorize("hasAuthority('ROLE_ADMIN')")
	@PostMapping("/addCar")
	public ResponseEntity<CarDTO> createCar(@RequestBody CarDTO carDto) {
		CarDTO createdCar = carService.createCar(carDto);
		return ResponseEntity.status(HttpStatus.CREATED).body(createdCar);
	}

	// url = http//localhost:8080/api/cars/updateCar/2
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@PutMapping("/updateCar/{id}")
	public ResponseEntity<CarDTO> updateCar(@PathVariable Long id, @RequestBody CarDTO carDto)
			throws ResourceNotFoundException {
		CarDTO updatedCar = carService.updateCar(id, carDto);
		return ResponseEntity.ok(updatedCar);
	}

	// url = http//localhost:8080/api/cars/delete/2
	@PreAuthorize("hasRole('ROLE_ADMIN')")
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Void> deleteCar(@PathVariable Long id) throws NoDataFoundException {
		boolean deleted = carService.deleteCar(id);
		if (deleted) {
			return ResponseEntity.noContent().build();
		} else {
			return ResponseEntity.notFound().build();
		}
	}

	// url = http//localhost:8080/api/cars/search/location/bhopal/availability/true
	@GetMapping("/search/location/{location}/availability/{availability}")
	public ResponseEntity<List<CarDTO>> searchCarsByLocationAndAvailability(@PathVariable("location") String location,
			@PathVariable("availability") boolean availability) throws NoDataFoundException {
		List<CarDTO> cars = carService.searchCarsByLocationAndAvailability(location, availability);
		return ResponseEntity.ok(cars);
	}

	// url = http//localhost:8080/api/cars/search/carType/SEDAN/availability/true
	@GetMapping("/search/carType/{carType}/availability/{availability}")
	public ResponseEntity<List<CarDTO>> searchCarsByCarTypeAndAvailability(@PathVariable Car.CarType carType,
			@PathVariable boolean availability) throws NoDataFoundException {
		List<CarDTO> cars = carService.searchCarsByCarTypeAndAvailability(carType, availability);
		return ResponseEntity.ok(cars);
	}

	// url = http//localhost:8080/api/cars/search/location/bhopal/carType/SEDAN/availability/true
	@GetMapping("/search/location/{location}/carType/{carType}/availability/{availability}")
	public ResponseEntity<List<CarDTO>> searchCarsByLocationAndCarTypeAndAvailability(@PathVariable String location,
			@PathVariable Car.CarType carType, @PathVariable boolean availability) throws NoDataFoundException {
		List<CarDTO> cars = carService.searchCarsByLocationAndCarTypeAndAvailability(location, carType, availability);
		return ResponseEntity.ok(cars);
	}

	// url = http//localhost:8080/api/cars/brand/maruti
	@GetMapping("/brand/{brand}")
	public ResponseEntity<List<CarDTO>> getCarsByBrand(@PathVariable("brand") String brand)
			throws ResourceNotFoundException {
		List<CarDTO> cars = carService.searchCarsByBrand(brand);
		return ResponseEntity.ok(cars);
	}

	// url = http//localhost:8080/api/cars/model/model
	@GetMapping("/model/{model}")
	public ResponseEntity<List<CarDTO>> getCarsByModel(@PathVariable("model") String model)
			throws ResourceNotFoundException {
		List<CarDTO> cars = carService.searchCarsByModel(model);
		return ResponseEntity.ok(cars);
	}

	// url = http//localhost:8080/api/cars/color/black
	@GetMapping("/color/{color}")
	public ResponseEntity<List<CarDTO>> getCarsByColor(@PathVariable("color") String color)
			throws ResourceNotFoundException {
		List<CarDTO> cars = carService.searchCarsByColor(color);
		return ResponseEntity.ok(cars);
	}

	// url = http//localhost:8080/api/cars/availability/true
	@GetMapping("/availability/{availability}")
	public ResponseEntity<List<CarDTO>> getCarsByAvailability(@PathVariable("availability") boolean availability)
			throws ResourceNotFoundException {
		List<CarDTO> cars = carService.searchCarsByAvailability(availability);
		return ResponseEntity.ok(cars);
	}

	// url = http//localhost:8080/api/cars/search/priceBetween/5000/10000
	@GetMapping("/search/priceBetween/{minPrice}/{maxPrice}")
	public ResponseEntity<List<CarDTO>> searchCarsByPriceBetween(@PathVariable("minPrice") double minPrice,
			@PathVariable("maxPrice") double maxPrice) throws NoDataFoundException {
		List<CarDTO> cars = carService.searchCarsByPriceBetween(minPrice, maxPrice);
		return ResponseEntity.ok(cars);
	}

	// url = http//localhost:8080/api/cars/search/brand/Maruti/color/{color}/availability/{availability}
	@GetMapping("/search/brand/{brand}/color/{color}/availability/{availability}")
	public ResponseEntity<List<CarDTO>> getCarsByBrandAndColorAndAvailability(@PathVariable String brand,
			@PathVariable String color, @PathVariable boolean availability) throws NoDataFoundException {
		List<CarDTO> cars = carService.searchCarsByBrandAndColorAndAvailability(brand, color, availability);
		return ResponseEntity.ok(cars);
	}

	// url = http//localhost:8080/api/cars/priceLessThan/5000
	@GetMapping("/priceLessThan/{price}")
	public ResponseEntity<List<CarDTO>> getCarsByPriceLessThan(@PathVariable("price") double price)
			throws NoDataFoundException {
		List<CarDTO> cars = carService.searchCarsByPriceLessThan(price);
		return ResponseEntity.ok(cars);
	}

	// url = http//localhost:8080/api/cars/priceGreaterThan/5000
	@GetMapping("/priceGreaterThan/{price}")
	public ResponseEntity<List<CarDTO>> getCarsByPriceGreaterThan(@PathVariable("price") double price)
			throws NoDataFoundException {
		List<CarDTO> cars = carService.searchCarsByPriceGreaterThan(price);
		return ResponseEntity.ok(cars);
	}

	// url = http//localhost:8080/api/cars/transmissionTypeAndAvailability/{transmissionType}/{availability}
	@GetMapping("/transmissionTypeAndAvailability/{transmissionType}/{availability}")
	public ResponseEntity<List<CarDTO>> getCarsByTransmissionTypeAndAvailability(
			@PathVariable("transmissionType") TransmissionType transmissionType,
			@PathVariable("availability") boolean availability) throws NoDataFoundException {
		List<CarDTO> cars = carService.searchCarsByTransmissionTypeAndAvailability(transmissionType, availability);
		return ResponseEntity.ok(cars);
	}

	// url = http//localhost:8080/api/cars/fuelTypeAndAvailability/{fuelType}/{availability}
	@GetMapping("/fuelTypeAndAvailability/{fuelType}/{availability}")
	public ResponseEntity<List<CarDTO>> getCarsByFuelTypeAndAvailability(@PathVariable("fuelType") FuelType fuelType,
			@PathVariable("availability") boolean availability) throws NoDataFoundException {
		List<CarDTO> cars = carService.searchCarsByFuelTypeAndAvailability(fuelType, availability);
		return ResponseEntity.ok(cars);
	}

	// url = http//localhost:8080/api/cars/brandAndPriceBetween/{brand}/{minPrice}/{maxPrice}
	@GetMapping("/brandAndPriceBetween/{brand}/{minPrice}/{maxPrice}")
	public ResponseEntity<List<CarDTO>> getCarsByBrandAndPriceBetween(@PathVariable("brand") String brand,
			@PathVariable("minPrice") double minPrice, @PathVariable("maxPrice") double maxPrice)
			throws NoDataFoundException {
		List<CarDTO> cars = carService.searchCarsByBrandAndPriceBetween(brand, minPrice, maxPrice);
		return ResponseEntity.ok(cars);
	}

	// url = http//localhost:8080/api/cars/locationAndTransmissionTypeAndAvailability/{location}/{transmissionType}/{availability}
	@GetMapping("/locationAndTransmissionTypeAndAvailability/{location}/{transmissionType}/{availability}")
	public ResponseEntity<List<CarDTO>> getCarsByLocationAndTransmissionTypeAndAvailability(
			@PathVariable("location") String location,
			@PathVariable("transmissionType") TransmissionType transmissionType,
			@PathVariable("availability") boolean availability) throws NoDataFoundException {
		List<CarDTO> cars = carService.searchCarsByLocationAndTransmissionTypeAndAvailability(location,
				transmissionType, availability);
		return ResponseEntity.ok(cars);
	}
}
